﻿using Assignment1.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment1.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class InfoController : ControllerBase
    {
        [HttpGet("GetInfo")]
        public void GetInfo()
        {
            Response.StatusCode = StatusCodes.Status201Created;
            Response.ContentType = "application/json";
            var response = "{\"Name\":\"Info\"}";
            Response.WriteAsync(response);

            //return "Information";
        }

        [HttpGet("GetData")]
        public IActionResult GetData()
        {
            return Ok(new { Name = "Data" });
        }

        [HttpGet("GetKnowledgeResult")]
        public IActionResult GetKnowledgeResult()
        {
            //return Ok(new { Name = "KnowledgeResult" });
            var response = new ObjectResult(new { Name = "KnowledgeResult" });
            response.StatusCode = StatusCodes.Status200OK;
            return response;
        }

        [HttpPost("PostRun")]
        public IActionResult PostRun([FromBody]Run run) 
        {
            return new OkObjectResult(run.Name);
        }
    }
}
